<head>
    <meta charset="UTF-8">
    <title>Kníhkupectvo chars</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Inria+Sans:wght@400;700&family=Merriweather:wght@400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/knihkupectvo/css/normalize.css">
    <link rel="stylesheet" href="/knihkupectvo/css/meta.css">
    <link rel="stylesheet" href="/knihkupectvo/css/styles.css">
    <style> html { font-size: 87.5%; }</style>

    <link rel="icon" type="image/png" sizes="32x32" href="/knihkupectvo/images/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/knihkupectvo/images/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/knihkupectvo/images/favicon-16x16.png">
    <meta name="theme-color" content="#283577">
</head>