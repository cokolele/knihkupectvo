<footer>
    Kníhkupectvo *chars online<br>
    <a href="https://github.com/cokolele/knihkupectvo">zdrojový kód</a>
</footer>